package br.com.portofoliodomarcio.erp.modulo_produto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModuloProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
